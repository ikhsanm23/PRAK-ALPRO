#include <iostream>
#include <fstream>
#include "../library/proses.h"

int main(){
  Proses proses;
  proses.cetak();
  proses.getData();
  proses.toFile();
  return 0;
};
